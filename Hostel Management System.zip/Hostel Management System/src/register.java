import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Project.ConnectionProvider;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.ImageIcon;

public class register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private JLabel lblUsername;
	private JLabel lblPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					register frame = new register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 701, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
		textField.setBounds(251, 139, 288, 36);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
		passwordField.setBounds(251, 203, 288, 36);
		contentPane.add(passwordField);
		
		JButton btnSignup = new JButton("SignUp");
		btnSignup.setFont(new Font("High Tower Text", Font.BOLD, 18));
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String uname = textField.getText();
				String pass = passwordField.getText();
				try {

					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("insert into login values(?,?)");
					ps.setString(1,uname);
					ps.setString(2,pass);
					ps.executeUpdate();
						new login().setVisible(true);
						
						JOptionPane.showMessageDialog(null,"SuccessFully signUp");
					
				}
				catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			    
			}
		});
		btnSignup.setBounds(251, 269, 108, 36);
		contentPane.add(btnSignup);
		
		lblUsername = new JLabel("UserName");
		lblUsername.setFont(new Font("High Tower Text", Font.BOLD, 18));
		lblUsername.setBounds(127, 136, 117, 36);
		contentPane.add(lblUsername);
		
		lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("High Tower Text", Font.BOLD, 18));
		lblPassword.setBounds(127, 203, 108, 36);
		contentPane.add(lblPassword);
		
		JLabel lblRegister = new JLabel("Register");
		lblRegister.setFont(new Font("High Tower Text", Font.BOLD, 18));
		lblRegister.setBounds(308, 24, 174, 41);
		contentPane.add(lblRegister);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnClose.setFont(new Font("High Tower Text", Font.BOLD, 18));
		btnClose.setBounds(431, 269, 108, 36);
		contentPane.add(btnClose);
		
		JLabel lblNewLabel = new JLabel(" ");
		lblNewLabel.setIcon(new ImageIcon(register.class.getResource("/images/pages background.jpg")));
		lblNewLabel.setBounds(0, 0, 685, 465);
		contentPane.add(lblNewLabel);
	}
}
