

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Project.ConnectionProvider;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public void clear() {
		textField.setText("");
		passwordField.setText("");
	}
	public login() {
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100,1200,700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLogIn = new JLabel("LOG IN");
		lblLogIn.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblLogIn.setBounds(772, 198, 112, 45);
		contentPane.add(lblLogIn);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblUsername.setBounds(650, 251, 112, 33);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Sylfaen", Font.BOLD, 24));
		lblPassword.setBounds(650, 303, 112, 33);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(772, 254, 184, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(772, 305, 184, 33);
		contentPane.add(passwordField);
		
		JCheckBox chckbxShowpassword = new JCheckBox("ShowPassword");
		chckbxShowpassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(chckbxShowpassword.isSelected())
				{
					
					passwordField.setEchoChar((char)0);
				}
				else
				{
					passwordField.setEchoChar('*');
			
				}
				}
		});
		chckbxShowpassword.setFont(new Font("Sylfaen", Font.BOLD, 19));
		chckbxShowpassword.setBounds(772, 364, 157, 23);
		contentPane.add(chckbxShowpassword);
		
		JButton btnLogIn = new JButton("Log In");
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/*
				String uname = textField.getText();
				String pass = passwordField.getText();
				try {
					Connection con = ConnectionProvider.getCon();
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("select * from login where username ='"+uname+"' and password ='"+pass+"'");
					if(rs.next())
					{
						setVisible(false);
						new home().setVisible(true);
						clear();
						JOptionPane.showMessageDialog(null,"SuccessFully Login");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"incorect Username Or Password");
						clear();
					}
					
				}
				catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			    } 
			
				*/
				 if(textField.getText().equals("hostel") && passwordField.getText().equals("admin"))
				{
					setVisible(false);
					new home().setVisible(true);
					JOptionPane.showMessageDialog(null,"SuccessFully Login");
				} 
				else

					JOptionPane.showMessageDialog(null,"incorect Username Or Password");
			} 
		});
		btnLogIn.setIcon(new ImageIcon(login.class.getResource("/images/login.png")));
		btnLogIn.setFont(new Font("Sylfaen", Font.BOLD, 24));
		btnLogIn.setBounds(779, 419, 137, 30);
		contentPane.add(btnLogIn);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int a=JOptionPane.showConfirmDialog(null,"Do You Really Want to Exit Application","Select",JOptionPane.YES_NO_OPTION);
				
				if(a==0)
				{
					System.exit(0);
					
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(login.class.getResource("/images/Close.png")));
		btnNewButton.setBounds(1243, 14, 80, 62);
		contentPane.add(btnNewButton);


		 
		
		JLabel label = new JLabel(" ");
		label.setIcon(new ImageIcon(login.class.getResource("/images/login background.PNG")));
		label.setBounds(0, 0, 1350, 729);
		contentPane.add(label);
	}
}
