import java.awt.BorderLayout;
import java.util.regex.*;


import java.sql.*;
import Project.ConnectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.Color;

public class NewStudent1 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
  
    private  JButton btnNewButton;
    private  JComboBox comboBox; 
	
     public void clear()
	{
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
		//comboBox.removeAllItems();
	    //roomNumber();
	
	}

	/* public void roomNumber()
	{
		int i=0;
		try
		{
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			//ResultSet rs=st.executeQuery("SELECT * FROM `room` WHERE activate='yes' and roomStatus='Booked'");
			ResultSet rs=st.executeQuery("select * from room where activate='yes'");
			//ResultSet rs =st.executeQuery("Select number from room");	
			
			while(rs.next())
			{		
				i=1;
				//comboBox.addItem(rs.getString(1)); 
				//comboBox.addItem(rs.getString(9));
				//comboBox.addItem("Working");
				
			}
			if(i==0)
			{
				btnNewButton.setVisible(false);
				
				JOptionPane.showMessageDialog(null,"All Rooms Are Already Booked");
				setVisible(false);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	} */

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStudent1 frame = new NewStudent1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public NewStudent1() {
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent arg0) {
				//roomNumber();
			}
		});
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.addComponentListener(new ComponentAdapter() {
			 @Override
			public void componentShown(ComponentEvent arg0) {
				//roomNumber();
			} 
			
		});

		contentPane.setSize(new Dimension());
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMobileNo = new JLabel("Mobile No");
		lblMobileNo.setForeground(Color.BLACK);
		lblMobileNo.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMobileNo.setBounds(67, 35, 89, 14);
		contentPane.add(lblMobileNo);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblName.setBounds(67, 73, 79, 14);
		contentPane.add(lblName);
		
		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblFatherName.setBounds(66, 121, 104, 14);
		contentPane.add(lblFatherName);
		
		JLabel lblMothername = new JLabel("MotherName");
		lblMothername.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMothername.setBounds(66, 172, 104, 14);
		contentPane.add(lblMothername);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblEmail.setBounds(67, 218, 57, 14);
		contentPane.add(lblEmail);
		
		JLabel lblPermantAddress = new JLabel("Permant Address");
		lblPermantAddress.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblPermantAddress.setBounds(66, 261, 135, 20);
		contentPane.add(lblPermantAddress);
		
		JLabel lblCollegeName = new JLabel("College Name");
		lblCollegeName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblCollegeName.setBounds(66, 313, 114, 14);
		contentPane.add(lblCollegeName);
		
		JLabel lblAddharNouniqueId = new JLabel("Addhar No(Unique Id)");
		lblAddharNouniqueId.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblAddharNouniqueId.setBounds(66, 364, 167, 14);
		contentPane.add(lblAddharNouniqueId);
		
		JLabel lblRoomNumber = new JLabel("Room Number");
		lblRoomNumber.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblRoomNumber.setBounds(66, 412, 135, 14);
		contentPane.add(lblRoomNumber);
		
		textField = new JTextField();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 int len = 0;
				if (len != 10) {
	                    JOptionPane.showMessageDialog(btnNewButton, "Enter a valid mobile number");
	                }

			}
		});
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(249, 29, 410, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str = textField_1.getText();
				if (str.equals("")){  //User have not entered anything. 
				    JOptionPane.showMessageDialog(null,"Please enter your name.");
				    textField_1.requestFocusInWindow();
				    //Do NOT loop here.
				}
				else { 
				    //Do everything you need to do when the user have entered something
				}
			}
			
		});
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(249, 67, 410, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(249, 115, 410, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(253, 166, 406, 27);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(253, 211, 406, 27);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(253, 258, 406, 27);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_6.setBounds(253, 307, 406, 27);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 int len = 0;
					if (len != 12) {
		                    JOptionPane.showMessageDialog(btnNewButton, "Enter a valid mobile number");
		                }

				
			}
		});
		textField_7.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_7.setBounds(253, 358, 406, 27);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		comboBox.setBounds(253, 402, 406, 27);
		contentPane.add(comboBox);
		int j = 0;
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			//ResultSet rs=st.executeQuery("SELECT * FROM `room` WHERE activate='yes' and roomStatus='Booked'");
			ResultSet rs=st.executeQuery("select * from room where activate='yes' and roomStatus='Not Booked'");
			//ResultSet rs =st.executeQuery("Select number from room");	
			
			while(rs.next())
			{		
				i = 1 ;
				j = 1 ;
				comboBox.addItem(rs.getString(1)); 
			}
			con.close();
			if(i==0)
			{
				JOptionPane.showMessageDialog(null,"Rooms Are Not Avilable ");
				btnNewButton.setVisible(false);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		button.setIcon(new ImageIcon(NewStudent1.class.getResource("/images/Close all jframe.png")));
		button.setBounds(780, 11, 108, 46);
		contentPane.add(button);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String mobile=textField.getText();
				String name=textField_1.getText();
				String father=textField_2.getText();
				String mother=textField_3.getText();
				String email=textField_4.getText();
				String add=textField_5.getText();
				String college=textField_6.getText();
				String aadhar=textField_7.getText();
				String room= comboBox.getSelectedItem().toString();
				String status="living";
				
				try
				{
					Connection con=ConnectionProvider.getCon();
					//PreparedStatement ps=con.prepareStatement("INSERT INTO `student` (`mobileNo`, `name`, `father`, `mother`, `email`, `address`, `college`, `aadhaar`, `roomNo`, `status`) VALUES('"+mn+"','"+na+"','"+fa+"','"+mo+"','"+el+"','"+add+"','"+col+"','"+adr+"','"+rn+"','"+stat+"')");
					PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1,mobile);
					ps.setString(2,name);
					ps.setString(3,father);
					ps.setString(4,mother);
					ps.setString(5,email);
					ps.setString(6,add);
					ps.setString(7,college);
					ps.setString(8,aadhar);
					ps.setString(9,room);
					ps.setString(10,status);
					
					
				/*	Pattern p1= Pattern.compile("^[0-9]{10}$");
					Matcher m1=p1.matcher(textField.getText());
					if(!m1.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid  mobile Number...");
						return ;
					}
					Pattern p= Pattern.compile("^[A-Za-z]+$");
					Matcher m=p.matcher(textField_1.getText());
					if(!m.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid Student Name...");
						return ;
					}
				    
					Pattern p2= Pattern.compile("^[A-Za-z]+$");
					Matcher m2=p2.matcher(textField_2.getText());
					if(!m.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid father Name...");
						return ;
					}
					Pattern p3= Pattern.compile("^[A-Za-z]+$");
					Matcher m3=p3.matcher(textField_3.getText());
					if(!m.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid Mother Name...");
						return ;
					}
					Pattern p4= Pattern.compile("^[a-z0-9+_.-]+@[a-z0-9.-]+$");
					Matcher m4=p4.matcher(textField_4.getText());
					if(!m2.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid Student Email...");
						return ;
					}
					Pattern p5= Pattern.compile("^[A-Za-z0-9]+$");
					Matcher m5=p5.matcher(textField_5.getText());
					if(!m3.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid Student Address...");
						return ;
					}
					Pattern p6= Pattern.compile("^[A-Za-z0-9]+$");
					Matcher m6=p6.matcher(textField_5.getText());
					if(!m3.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid College Name...");
						return ;
					}
					Pattern p7= Pattern.compile("^[0-11]{12}$");
					Matcher m7=p7.matcher(textField_6.getText());
					if(!m1.matches())
					{
						JOptionPane.showMessageDialog(null,"Invalid  Adhar Number...");
						return ;
					}*/
					ps.executeUpdate();
					
					PreparedStatement ps1=con.prepareStatement("UPDATE room SET roomStatus='Booked' WHERE number=?");
                     ps1.setString(1,room);

					ps1.executeUpdate(); 
					JOptionPane.showMessageDialog(null,"Student SuccessFully Added");
					textField.setEditable(false);
		
					clear(); 
					
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			
				
				
			}
			
		});
		if(j==0)
		{
			btnNewButton.setVisible(true);
		} 
		
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton.setIcon(new ImageIcon(NewStudent1.class.getResource("/images/save.png")));
		btnNewButton.setBounds(249, 447, 104, 42);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});
		btnNewButton_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_1.setIcon(new ImageIcon(NewStudent1.class.getResource("/images/clear.png")));
		btnNewButton_1.setBounds(555, 447, 104, 42);
		contentPane.add(btnNewButton_1);
		
		/* JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		comboBox.setBounds(231, 402, 280, 27);
		contentPane.add(comboBox);
		try
		{
			int i = 0;
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			//ResultSet rs=st.executeQuery("SELECT * FROM `room` WHERE activate='yes' and roomStatus='Booked'");
			ResultSet rs=st.executeQuery("select * from room where activate='yes'");
			//ResultSet rs =st.executeQuery("Select number from room");	
			
			while(rs.next())
			{		
				i = 1 ;
				comboBox.addItem(rs.getString(1)); 
				//comboBox.addItem(rs.getString(9));
				//comboBox.addItem("Working");
				
				
			}
			con.close();
			if(i==0)
			{
				btnNewButton.setVisible(false);
				
				JOptionPane.showMessageDialog(null,"All Rooms Are Already Booked");
				setVisible(false);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		} */
		
	
		JLabel label = new JLabel(" ");
		label.setForeground(Color.RED);
		label.setIcon(new ImageIcon(NewStudent1.class.getResource("")));
		label.setBounds(0, 0, 690, 489);
		contentPane.add(label);
	
		 
	}
}
