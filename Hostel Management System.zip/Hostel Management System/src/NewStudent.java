import java.awt.BorderLayout;
import java.util.regex.*;



import java.sql.*;
import Project.ConnectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.Color;

public class NewStudent extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
  
     private  JButton btnNewButton;
     private  JComboBox comboBox; 
	public void clear()
	{
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
		textField_8.setText("");
		comboBox.removeAllItems();
	    roomNumber();
	
	}
 
	public void roomNumber()
	{
		int i=0;
		try
		{
			Connection con=ConnectionProvider.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select *from room where activate='yes'  and roomStatus='Not Booked'");
			while(rs.next())
			{
				i=1;
				comboBox.addItem(rs.getString(1));
			}
			if(i==0)
			{
				btnNewButton.setVisible(false);
				
				JOptionPane.showMessageDialog(null,"All Rooms Are Already Booked");
				setVisible(false);
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
	}
	
	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewStudent frame = new NewStudent();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewStudent() {
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent arg0) {
				roomNumber();
			}
		});
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(480, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent arg0) {
				
			}
			
		});
		contentPane.setSize(new Dimension());
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMobileNo = new JLabel("Mobile No");
		lblMobileNo.setForeground(Color.BLACK);
		lblMobileNo.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMobileNo.setBounds(67, 35, 89, 14);
		contentPane.add(lblMobileNo);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblName.setBounds(67, 73, 79, 14);
		contentPane.add(lblName);
		
		JLabel lblFatherName = new JLabel("Father Name");
		lblFatherName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblFatherName.setBounds(66, 121, 104, 14);
		contentPane.add(lblFatherName);
		
		JLabel lblMothername = new JLabel("MotherName");
		lblMothername.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMothername.setBounds(66, 172, 104, 14);
		contentPane.add(lblMothername);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblEmail.setBounds(67, 218, 57, 14);
		contentPane.add(lblEmail);
		
		JLabel lblPermantAddress = new JLabel("Permant Address");
		lblPermantAddress.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblPermantAddress.setBounds(66, 261, 135, 20);
		contentPane.add(lblPermantAddress);
		
		JLabel lblCollegeName = new JLabel("College Name");
		lblCollegeName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblCollegeName.setBounds(66, 313, 114, 14);
		contentPane.add(lblCollegeName);
		
		JLabel lblAddharNouniqueId = new JLabel("Addhar No(Unique Id)");
		lblAddharNouniqueId.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblAddharNouniqueId.setBounds(66, 364, 167, 14);
		contentPane.add(lblAddharNouniqueId);
		
		JLabel lblRoomNumber = new JLabel("Room Number");
		lblRoomNumber.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblRoomNumber.setBounds(66, 412, 135, 14);
		contentPane.add(lblRoomNumber);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(249, 29, 410, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
			
		});
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(249, 67, 410, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(249, 115, 410, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(253, 166, 406, 27);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(253, 211, 406, 27);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(253, 258, 406, 27);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_6.setBounds(253, 307, 406, 27);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		textField_7.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_7.setBounds(253, 358, 406, 27);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		button.setIcon(new ImageIcon(NewStudent.class.getResource("/images/Close all jframe.png")));
		button.setBounds(798, 11, 114, 46);
		contentPane.add(button);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mobileNo = textField.getText();
				String name = textField_1.getText();
				String father = textField_2.getText();
				String mother = textField_3.getText();
				String email = textField_4.getText();
				String address = textField_5.getText();
				String college = textField_6.getText();
				String aadhaar = textField_7.getText();
				String roomNo =comboBox.getSelectedItem().toString();
				String status = "living";
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?)");
					ps.setString(1,mobileNo);
					ps.setString(2,name);
					ps.setString(3,father);
					ps.setString(4,mother);
					ps.setString(5,email);
					ps.setString(6,address);
					ps.setString(7,college);
					ps.setString(8,aadhaar);
					ps.setString(9,roomNo);
					ps.setString(10,status);
					ps.executeUpdate();
					PreparedStatement ps1 = con.prepareStatement("update room set roomStatus='booked' where number=?");
					ps1.setString(1,roomNo);
					 

					ps1.executeUpdate();
					JOptionPane.showMessageDialog(null,"SuccessFully Added");
					
					clear(); 
					
					
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			
		 
			
			if(textField.getText().equals(""))
			{
				
				
			}
			else
			{
				JOptionPane.showMessageDialog(null,"incorect Username Or Password");
				
				 
		
			}
			}

			private void addFieldError(String string, String string2) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton.setIcon(new ImageIcon(NewStudent.class.getResource("/images/save.png")));
		btnNewButton.setBounds(249, 447, 104, 42);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});
		btnNewButton_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_1.setIcon(new ImageIcon(NewStudent.class.getResource("/images/clear.png")));
		btnNewButton_1.setBounds(555, 447, 104, 42);
		contentPane.add(btnNewButton_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		comboBox.setBounds(253, 402, 406, 27);
		contentPane.add(comboBox);
 
		 
	}
}
