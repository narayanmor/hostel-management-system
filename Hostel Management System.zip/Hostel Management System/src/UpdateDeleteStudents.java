import java.awt.BorderLayout;
import java.sql.*;
import Project.ConnectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Component;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class UpdateDeleteStudents extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JComboBox comboBox ;

	/**
	 * Launch the application.
	 */
	public void clear()
	{
		textField.setEditable(true);
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
		textField_8.setText("");
	    comboBox.removeAllItems(); 
		
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateDeleteStudents frame = new UpdateDeleteStudents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateDeleteStudents() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setLocation(new Point(480, 150));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMobileNo = new JLabel("Mobile No");
		lblMobileNo.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMobileNo.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblMobileNo.setBounds(97, 24, 140, 33);
		contentPane.add(lblMobileNo);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblName.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblName.setBounds(97, 52, 140, 35);
		contentPane.add(lblName);
		
		JLabel lblNewLabel = new JLabel("FatherName");
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel.setBounds(97, 98, 140, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("MotherName");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_1.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel_1.setBounds(97, 136, 140, 25);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_2.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel_2.setBounds(97, 172, 140, 19);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Permant Address");
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_3.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel_3.setBounds(97, 213, 140, 23);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Colege Name");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_4.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblNewLabel_4.setBounds(97, 258, 140, 24);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblAddharNo = new JLabel("Addhar No");
		lblAddharNo.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblAddharNo.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblAddharNo.setBounds(97, 293, 140, 27);
		contentPane.add(lblAddharNo);
		
		JLabel lblR = new JLabel("Room No\r\n");
		lblR.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblR.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblR.setBounds(97, 335, 140, 33);
		contentPane.add(lblR);
		
		JLabel lblLivingStatus = new JLabel("Living  Status");
		lblLivingStatus.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblLivingStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblLivingStatus.setBounds(97, 393, 140, 25);
		contentPane.add(lblLivingStatus);
		
		textField = new JTextField();
		textField.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField.setBounds(244, 26, 295, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_1.setBounds(245, 63, 429, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_2.setBounds(245, 100, 429, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_3.setBounds(245, 138, 429, 27);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_4.setBounds(245, 175, 429, 27);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_5.setBounds(245, 220, 429, 24);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_6.setBounds(245, 255, 429, 27);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_7.setBounds(245, 295, 429, 27);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		textField_8.setBounds(245, 340, 429, 27);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"leaved", "living"}));
		comboBox.setBounds(245, 394, 258, 33);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Search\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			       String mobile = textField.getText();
				try {
					Connection con= ConnectionProvider.getCon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from student where mobileNo='"+mobile+"'");
					if(rs.next())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_4.setText(rs.getString(5));
						textField_5.setText(rs.getString(6));
						textField_6.setText(rs.getString(7));
						textField_7.setText(rs.getString(8));
						textField_8.setText(rs.getString(9));
						textField_8.setEditable(false);
						if(rs.getString(10).equals("living"))
						{
							comboBox.addItem("living");
							comboBox.addItem("leaved");
							
						}
						else
						{
							comboBox.addItem("leaved");
							comboBox.addItem("living");
						}
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Student does not Exist");
						clear();
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				} 
			}

		});
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 15));
		btnNewButton.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/search.png")));
		btnNewButton.setBounds(564, 25, 109, 29);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		button.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/Close all jframe.png")));
		button.setBounds(748, 12, 101, 51);
		contentPane.add(button);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mobile = textField.getText();
				String name = textField_1.getText();
				String fname = textField_2.getText();
				String mname = textField_3.getText();
				String email = textField_4.getText();
				String add = textField_5.getText();
				String college = textField_6.getText();
				String aadhar = textField_7.getText();
				String roomnumber= textField_8.getText();
				String status = comboBox.getSelectedItem().toString(); 
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("update student set mobileNo=?,name=?,father=?,mother=?,email=?,address=?,aadhaar=?,college=?,roomNo=?,status=? where mobileNo='"+mobile+"'");
					ps.setString(1,mobile);
					ps.setString(2,name);
					ps.setString(3,fname);
					ps.setString(4,mname);
					ps.setString(5,email);
					ps.setString(6,add);
					ps.setString(7,aadhar);
					ps.setString(8,college);
					ps.setString(9,roomnumber);
					ps.setString(10,status);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Student Successfully Updated");
					clear(); 
					//textField.setEditable(true);
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}
	

			
		});
		btnSave.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSave.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/save.png")));
		btnSave.setBounds(251, 451, 109, 38);
		contentPane.add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});
		btnClear.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/clear.png")));
		btnClear.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnClear.setBounds(568, 450, 109, 38);
		contentPane.add(btnClear);
		
		JButton btnCancle = new JButton("Delete");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mobile = textField.getText();
				try{
					Connection con = ConnectionProvider.getCon();
					java.sql.Statement st = con.createStatement();
					st.executeUpdate("delete from student where mobileNo='"+mobile+"'");
					JOptionPane.showMessageDialog(null,"Student SuccessFully Deleted");
					clear();
					//textField.setEditable(true);
				}
				catch (Exception e) {
					JOptionPane.showMessageDialog(null,e);
				}
			
			}
		});
		btnCancle.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnCancle.setIcon(new ImageIcon(UpdateDeleteStudents.class.getResource("/images/delete.png")));
		btnCancle.setBounds(406, 452, 117, 38);
		contentPane.add(btnCancle);
	}
}
