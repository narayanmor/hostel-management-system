import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.*;
import java.text.SimpleDateFormat;

import Project.ConnectionProvider;
import java.awt.EventQueue;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JScrollPane;

public class StudentFees1 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	private JButton btnNewButton;
   

	
	public void clear()
	{
		textField.setEditable(true);
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
	}
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);
		String mobileNo=textField.getText();
		try
		{
			Connection con=ConnectionProvider.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select *from fees where mobileNo='"+mobileNo+"'"); 
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(2),rs.getString(3)});
			}

		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
		
		
		
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentFees1 frame = new StudentFees1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public StudentFees1() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});

		button.setIcon(new ImageIcon(StudentFees.class.getResource("/images/Close all jframe.png")));
		button.setBounds(792, 13, 100, 48);
		contentPane.add(button);
		
		JLabel lblMobileNumber = new JLabel("Mobile Number");
		lblMobileNumber.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMobileNumber.setBounds(58, 40, 140, 22);
		contentPane.add(lblMobileNumber);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblName.setBounds(58, 90, 46, 14);
		contentPane.add(lblName);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblEmail.setBounds(58, 139, 46, 14);
		contentPane.add(lblEmail);
		
		JLabel lblMonth = new JLabel("Month");
		lblMonth.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMonth.setBounds(58, 233, 89, 14);
		contentPane.add(lblMonth);
		
		JLabel lblAmountToBe = new JLabel("Amount to be pay");
		lblAmountToBe.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblAmountToBe.setBounds(58, 279, 140, 22);
		contentPane.add(lblAmountToBe);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(209, 36, 405, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(208, 82, 406, 30);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(209, 131, 405, 30);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(209, 176, 405, 30);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(208, 225, 406, 30);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(208, 275, 406, 30);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblRoomNumber = new JLabel("Room Number");
		lblRoomNumber.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblRoomNumber.setBounds(58, 180, 122, 22);
		contentPane.add(lblRoomNumber);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobileNo=textField.getText();
				SimpleDateFormat dFormat=new SimpleDateFormat("MM-YYYY");
				Date date=new Date();
				String month=dFormat.format(date);
				try
				{
					Connection con=ConnectionProvider.getCon();
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select * from student where mobileNo='"+mobileNo+"' and status='Living'"); 
					if(rs.next())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(5));
						textField_3.setText(rs.getString(9 ));
						textField_4.setText(month);
						textField_5.setText("10500");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Student Does Not Exit");
						clear();
						
					}
					tableDetails();
					
					ResultSet rs1=st.executeQuery("select * from fees inner join student where student.status='Living' and fees.month='"+month+"' and fees.mobileNo='"+mobileNo+"'  and student.mobileNo='"+mobileNo+"'"); 
					if(rs1.next())
					{
						
						tableDetails();
						JOptionPane.showMessageDialog(null,"All ready paid");
						//btnNewButton.setVisible(false);
						clear();
					}
				}
				
				catch(Exception e1)
				
				{
					JOptionPane.showMessageDialog(null,e1);
					
				}
				
			}
		});
		btnSearch.setIcon(new ImageIcon(StudentFees1.class.getResource("/images/search.png")));
		btnSearch.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSearch.setBounds(638, 31, 112, 33);
		contentPane.add(btnSearch);
		
		JButton btnNewButton = new JButton(" Save\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String mobileNo=textField.getText();
				String month=textField_4.getText();
				String amount=textField_5.getText();
			
				try {
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("insert into fees (mobileNo,month,amount) VALUES ('"+mobileNo+"','"+month+"','"+amount+"')");
					ps.executeUpdate();
					tableDetails();
					JOptionPane.showMessageDialog(null,"SuccessFully Added");
					clear(); 
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null,e);
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton.setIcon(new ImageIcon(StudentFees1.class.getResource("/images/save.png")));
		btnNewButton.setBounds(209, 316, 105, 39);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});
		btnNewButton_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_1.setIcon(new ImageIcon(StudentFees1.class.getResource("/images/clear.png")));
		btnNewButton_1.setBounds(507, 316, 105, 39);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 379, 680, 100);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Bookman Old Style", Font.BOLD, 11));
		table.setModel(new DefaultTableModel(
			new Object[][] { /*
				{null, null},
				{null, null},
				{null, null},
				{null, null}, */
			},
			new String[] {
				"Month", "Amount"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		 
		
	}

}
