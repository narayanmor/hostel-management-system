import java.awt.BorderLayout;
import java.sql.*;
import Project.ConnectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class AllEmployeeWorking extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AllEmployeeWorking frame = new AllEmployeeWorking();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AllEmployeeWorking() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton(" ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btnNewButton.setIcon(new ImageIcon(AllEmployeeWorking.class.getResource("/images/Close all jframe.png")));
		btnNewButton.setBounds(811, 11, 79, 47);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 80, 880, 332);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Bookman Old Style", Font.BOLD, 11));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			
			},
			new String[] {
				"Name", "Mobile No", " FatherName", " MotherName", "Email", "Address", "AAdhar No", "Designation"
			}
		));
		scrollPane.setViewportView(table);
	
		JButton btnPrint = new JButton("PRINT");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					 table.print(JTable.PrintMode.FIT_WIDTH);
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			
			}
		});
		btnPrint.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
		btnPrint.setIcon(new ImageIcon(AllStudentsLiving.class.getResource("/images/print.png")));
		btnPrint.setBounds(789, 415, 101, 32);
		contentPane.add(btnPrint);
	DefaultTableModel model = (DefaultTableModel)table.getModel();
	try {
		Connection con = ConnectionProvider.getCon();
		Statement st = con.createStatement();
		ResultSet rs =  st.executeQuery("select * from employee where status='Working'");
		while(rs.next()) {
			model.addRow(new Object [] { rs.getString(2),rs.getString(1),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)
			});
		}
	}
	catch(Exception e) {
		JOptionPane.showMessageDialog(null, e);
	}
}


}
