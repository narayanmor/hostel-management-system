import java.awt.BorderLayout;
import java.sql.*;
import java.text.SimpleDateFormat;

import Project.ConnectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EmployeePayment extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	private JButton btnSearch;
	private JButton btnUpdate;
	private JButton btnClear;

	/**
	 * Launch the application.
	 */
	public void clear() {
		btnUpdate.setVisible(true);
		textField.setEditable(true );
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		DefaultTableModel dtm = (DefaultTableModel)table.getModel();
		dtm.setRowCount(0);
	}
	
	public void tableDetails() {
		DefaultTableModel dtm = (DefaultTableModel)table.getModel();
		dtm.setRowCount(0);
		String mobile = textField.getText();
		try {
			Connection con = ConnectionProvider.getCon();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from payment where mobileNO='"+mobile+"'");
			while(rs.next()) {
				dtm.addRow(new Object[] {rs.getString(2),rs.getString(3)});
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeePayment frame = new EmployeePayment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeePayment() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mobile No");
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel.setBounds(10, 47, 98, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_1.setBounds(10, 90, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email");
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_2.setBounds(10, 132, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Designation");
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_3.setBounds(10, 177, 98, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Month");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_4.setBounds(10, 216, 98, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Payment Amount");
		lblNewLabel_5.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_5.setBounds(10, 258, 137, 14);
		contentPane.add(lblNewLabel_5);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(195, 47, 357, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(195, 87, 491, 30);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(195, 129, 491, 30);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(195, 174, 491, 30);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(195, 213, 491, 30);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(195, 255, 491, 30);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		btnNewButton.setIcon(new ImageIcon(EmployeePayment.class.getResource("/images/Close all jframe.png")));
		btnNewButton.setBounds(792, 11, 98, 49);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(127, 374, 619, 145);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"Month", "Amount"
			}
		));
		scrollPane.setViewportView(table);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobile = textField.getText();
				SimpleDateFormat dFormat = new SimpleDateFormat("DD-MMM-YYYY");
				Date date = new Date(0);
				String month = dFormat.format(date);
				
				try {
					Connection con = ConnectionProvider.getCon();
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("Select * from employee where mobileNo='"+mobile+"' and status = 'Working'");
					if(rs.next())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(5));
						textField_3.setText(rs.getString(8));
						textField_4.setText(month);
						textField_5.setText("10000");
						
					}
					else
					{
						JOptionPane.showMessageDialog(null, "User does not Exist");
					}
					String test = "Working";
					ResultSet rs1 = st.executeQuery("select * from payment inner join employee where employee.status='"+test+"' and payment.month='"+month+"' and payment.mobileNo='"+mobile+"' and employee.mobileNo='"+mobile+"'");
					if(rs1.next()) {
						btnUpdate.setVisible(false);
						tableDetails();
						JOptionPane.showMessageDialog(null, "Payment is already Done");
						
					}
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
	
			}
		});
		btnSearch.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSearch.setIcon(new ImageIcon(EmployeePayment.class.getResource("/images/search.png")));
		btnSearch.setBounds(566, 47, 120, 30);
		contentPane.add(btnSearch);
		
		btnUpdate = new JButton("Save");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobile = textField.getText();
				String month = textField_4.getText();
				String amount = textField_5.getText();
				try {
					Connection con = ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("insert into payment values(?,?,?)");
					ps.setString(1,mobile);
					ps.setString(2,month);
					ps.setString(3,amount);
					ps.executeUpdate();
					tableDetails();
					JOptionPane.showMessageDialog(null,"Successfully Updated");
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);			}
		
			}
		});
		btnUpdate.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnUpdate.setIcon(new ImageIcon(EmployeePayment.class.getResource("/images/save.png")));
		btnUpdate.setBounds(195, 309, 108, 40);
		contentPane.add(btnUpdate);
		
		btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		btnClear.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnClear.setIcon(new ImageIcon(EmployeePayment.class.getResource("/images/clear.png")));
		btnClear.setBounds(578, 309, 108, 40);
		contentPane.add(btnClear);
	}
}
