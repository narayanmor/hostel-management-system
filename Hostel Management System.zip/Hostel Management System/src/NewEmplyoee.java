import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Project.ConnectionProvider;

import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class NewEmplyoee extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public void clear() {
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
	
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewEmplyoee frame = new NewEmplyoee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewEmplyoee() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380,150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		button.setIcon(new ImageIcon(NewEmplyoee.class.getResource("/images/Close all jframe.png")));
		button.setBounds(772, 11, 91, 47);
		contentPane.add(button);
		
		JLabel lblNewLabel = new JLabel("Mobile Number\r\n");
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel.setBounds(10, 53, 127, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_1.setBounds(10, 100, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("FatherName");
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_2.setBounds(10, 149, 127, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel(" MotherName");
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_3.setBounds(10, 202, 127, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel(" Email");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_4.setBounds(10, 253, 78, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("PermantAddress");
		lblNewLabel_5.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_5.setBounds(10, 300, 127, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel(" Addhar No(Unique Id)");
		lblNewLabel_6.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_6.setBounds(10, 342, 172, 21);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Designation");
		lblNewLabel_7.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_7.setBounds(10, 392, 105, 14);
		contentPane.add(lblNewLabel_7);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(219, 46, 468, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(219, 93, 468, 28);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(219, 142, 468, 28);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(219, 195, 468, 28);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(219, 246, 468, 28);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(219, 293, 468, 28);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_6.setBounds(219, 338, 468, 28);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Maintance", "Cook", "Housekeeping", "Purchasing", "Inventry Control", "Counting", "Quality Control", ""}));
		comboBox.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		comboBox.setBounds(219, 385, 468, 28);
		contentPane.add(comboBox);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mobile = textField.getText();
				String name = textField_1.getText();
				String fname = textField_2.getText();
				String mname = textField_3.getText();
				String email = textField_4.getText();
				String add = textField_5.getText();
				String aadhar = textField_6.getText();
				String designation = comboBox.getSelectedItem().toString();
				String status = "working";
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?)");
					ps.setString(1,mobile);
					ps.setString(2,name);
					ps.setString(3,fname);
					ps.setString(4,mname);
					ps.setString(5,email);
					ps.setString(6,add);
					ps.setString(7,aadhar);
					ps.setString(8,designation);
					ps.setString(9,status);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Employee SuccessFully Added");
					clear(); 
					
				}
				catch(Exception e)
				{
					JOptionPane.showMessageDialog(null, e);
				}
			}
		});
		btnSave.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSave.setIcon(new ImageIcon(NewEmplyoee.class.getResource("/images/save.png")));
		btnSave.setBounds(219, 451, 101, 38);
		contentPane.add(btnSave);
		
		JButton btnNewButton = new JButton(" Clear");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				clear();
			}
		});
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton.setIcon(new ImageIcon(NewEmplyoee.class.getResource("/images/clear.png")));
		btnNewButton.setBounds(575, 451, 112, 38);
		contentPane.add(btnNewButton);
	}
}
