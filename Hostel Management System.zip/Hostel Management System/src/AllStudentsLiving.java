import java.awt.BorderLayout;
import Project.ConnectionProvider;
import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Color;

public class AllStudentsLiving extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 * @return 
	 */

	public void tableDetails() {
	DefaultTableModel model=(DefaultTableModel) table.getModel();
	table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
	try {
		Connection con=ConnectionProvider.getCon();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select *from student where status='living'"); 
		while(rs.next())
		{
		model.addRow(new Object[] {rs.getString(2),rs.getString(1),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)});
		}
		}
	catch(Exception e)
	{
		JOptionPane.showMessageDialog(null,e);
	}
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AllStudentsLiving frame = new AllStudentsLiving();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AllStudentsLiving() {
				setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380,150,900,530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton(" ");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			setVisible(false);
			}
			
		});
	
		
		button.setIcon(new ImageIcon(AllStudentsLiving.class.getResource("/images/Close all jframe.png")));
		button.setBounds(816, 11, 74, 45);
		contentPane.add(button);
		
		JScrollPane scrollPane =new JScrollPane();
		scrollPane.setBounds(10, 67, 880, 316);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Bookman Old Style", Font.BOLD, 11));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				" Name", "Mobile Number", " FatherName", "MotherName", "Email", "Address", "CollegeName", "Addhar No", "Room Number"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnPrint = new JButton("PRINT");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					 table.print(JTable.PrintMode.FIT_WIDTH);
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			
			}
		});
		btnPrint.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
		btnPrint.setIcon(new ImageIcon(AllStudentsLiving.class.getResource("/images/print.png")));
		btnPrint.setBounds(789, 415, 101, 32);
		contentPane.add(btnPrint);
		tableDetails();
	}

	private void initComponants() {
		// TODO Auto-generated method stub
		
	}


}
