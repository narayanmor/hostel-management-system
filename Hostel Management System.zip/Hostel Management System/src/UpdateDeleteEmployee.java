import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Project.ConnectionProvider;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class UpdateDeleteEmployee extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public void clear() {
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
		textField_6.setText("");
		textField_7.setText("");
	
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateDeleteEmployee frame = new UpdateDeleteEmployee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateDeleteEmployee() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton(" ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			setVisible(false);
			}
			
		});
		btnNewButton.setIcon(new ImageIcon(UpdateDeleteEmployee.class.getResource("/images/Close all jframe.png")));
		btnNewButton.setBounds(801, 11, 89, 43);
		contentPane.add(btnNewButton);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		comboBox.setBounds(209, 387, 459, 30);
		contentPane.add(comboBox);
		
		JLabel lblMobileNumber = new JLabel("Mobile Number");
		lblMobileNumber.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblMobileNumber.setBounds(22, 39, 142, 14);
		contentPane.add(lblMobileNumber);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel.setBounds(22, 77, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(" Father Name");
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_1.setBounds(10, 114, 142, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("MotherName");
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_2.setBounds(22, 170, 142, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Email");
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_3.setBounds(22, 217, 86, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel(" Permant Address");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_4.setBounds(10, 258, 142, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel(" Addhar No(Unique Id)");
		lblNewLabel_5.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_5.setBounds(10, 302, 182, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("  Designation");
		lblNewLabel_6.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblNewLabel_6.setBounds(10, 355, 156, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblLivingStatus = new JLabel("Living Status");
		lblLivingStatus.setFont(new Font("Sylfaen", Font.BOLD, 16));
		lblLivingStatus.setBounds(22, 395, 182, 14);
		contentPane.add(lblLivingStatus);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(209, 31, 346, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(209, 69, 459, 30);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_2.setBounds(209, 114, 459, 30);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_3.setBounds(209, 162, 459, 30);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_4.setBounds(209, 209, 459, 30);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_5.setBounds(209, 250, 459, 30);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_6.setBounds(209, 294, 459, 30);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_7.setBounds(209, 347, 459, 30);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobile = textField.getText();
				String name = textField_1.getText();
				String fname = textField_2.getText();
				String mname = textField_3.getText();
				String email = textField_4.getText();
				String add = textField_5.getText();
				String aadhar = textField_6.getText();
				String designation = textField_7.getText();
				String status = comboBox.getSelectedItem().toString(); 
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps = con.prepareStatement("update employee set mobileNo=?,name=?,father=?,mother=?,email=?,address=?,aadhaar=?,designation=?,status=? where mobileNo='"+mobile+"'");
					ps.setString(1,mobile);
					ps.setString(2,name);
					ps.setString(3,fname);
					ps.setString(4,mname);
					ps.setString(5,email);
					ps.setString(6,add);
					ps.setString(7,aadhar);
					ps.setString(8,designation);
					ps.setString(9,status);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null," Employee Successfully Updated");
					clear(); 
					//textField.setEditable(true);
					
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
				}
			}
	

		});
		btnNewButton_1.setIcon(new ImageIcon(UpdateDeleteEmployee.class.getResource("/images/save.png")));
		btnNewButton_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_1.setBounds(209, 455, 122, 34);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Delete");
		btnNewButton_2.setIcon(new ImageIcon(UpdateDeleteEmployee.class.getResource("/images/delete.png")));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String mobile = textField.getText();
				try{
					Connection con = ConnectionProvider.getCon();
					java.sql.Statement st = con.createStatement();
					st.executeUpdate("delete from employee where mobileNo='"+mobile+"'");
					JOptionPane.showMessageDialog(null,"SuccessFully Deleted");
					clear();
					//textField.setEditable(true);
				}
				catch (Exception e) {
					JOptionPane.showMessageDialog(null,e);
				}
			}
		
		});
		btnNewButton_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_2.setBounds(389, 455, 122, 34);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Clear");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		btnNewButton_3.setIcon(new ImageIcon(UpdateDeleteEmployee.class.getResource("/images/clear.png")));
		btnNewButton_3.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnNewButton_3.setBounds(565, 455, 103, 34);
		contentPane.add(btnNewButton_3);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String mobile = textField.getText();
				try {
					Connection con= ConnectionProvider.getCon();
					java.sql.Statement st= con.createStatement();
					ResultSet rs = ((java.sql.Statement) st).executeQuery("select * from employee where mobileNo='"+mobile+"'");
					if(rs.next())
					{
						textField.setEditable(false);
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_4.setText(rs.getString(5));
						textField_5.setText(rs.getString(6));
						textField_6.setText(rs.getString(7));
						textField_7.setText(rs.getString(8));
						if(rs.getString(9).equals("Working"))
						{
							comboBox.addItem("Working");
							comboBox.addItem("Not Working");
							
						}
						else
						{
							comboBox.addItem("Not Working");
							comboBox.addItem("Working");
						}
					}
					else 
					{
						JOptionPane.showMessageDialog(null, "Employee does not Exist");
						clear();
					}
					
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				} 
			}

		
		});
		btnSearch.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSearch.setBounds(579, 27, 89, 34);
		contentPane.add(btnSearch);
	}
}
