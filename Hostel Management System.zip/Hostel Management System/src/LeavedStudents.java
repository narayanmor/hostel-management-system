import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Project.ConnectionProvider;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class LeavedStudents extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public void tableDetails() {
		DefaultTableModel model=(DefaultTableModel) table.getModel();
		table.setAutoResizeMode(table.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		try {
			Connection con=ConnectionProvider.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select *from student where status='leaved'"); 
			while(rs.next())
			{
			model.addRow(new Object[] {rs.getString(2),rs.getString(1),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)});
			}
			}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
		}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LeavedStudents frame = new LeavedStudents();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LeavedStudents() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150,900,530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton(" ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		btnNewButton.setBounds(811, 11, 79, 47);
		btnNewButton.setIcon(new ImageIcon(LeavedStudents.class.getResource("/images/Close all jframe.png")));
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 91, 870, 272);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Bookman Old Style", Font.BOLD, 11));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				
			},
			new String[] {
				"Name", "Mobile No", "FatherName", "MotherName", "Email", "Address", "CollegeName", "Addhar No", "Room No"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnPrint = new JButton("PRINT");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					 table.print(JTable.PrintMode.FIT_WIDTH);
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			
			
			}
		});
		btnPrint.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
		btnPrint.setIcon(new ImageIcon(LeavedStudents.class.getResource("/images/print.png")));
		btnPrint.setBounds(783, 415, 107, 31);
		contentPane.add(btnPrint);
		tableDetails();
	}
}
