

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowEvent;

public class home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home frame = new home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public home() {
		addWindowFocusListener(new WindowFocusListener() {
			public void windowGainedFocus(WindowEvent arg0) {

			 
				 
				
			}
			public void windowLostFocus(WindowEvent arg0) {
				
			}
		});
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100,1300,700);
		contentPane = new JPanel();
		contentPane.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				
			
				}
		});
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton JButton1 = new JButton("ManageRoom");
		JButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 
				 new ManageRoom().setVisible(true);
				
			}
		});
		JButton1.setBounds(20, 85, 271, 43);
		JButton1.setIcon(new ImageIcon(home.class.getResource("/images/room.png")));
		JButton1.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton1);
		
		JButton JButton2 = new JButton("NewStudent");
		JButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
                              
                        new NewStudent1().setVisible(true); 
			}
		});
		JButton2.setBounds(20, 139, 271, 39);
		JButton2.setIcon(new ImageIcon(home.class.getResource("/images/new student.png")));
		JButton2.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton2);
		
		JButton JButton3 = new JButton("Update & Delete Students");
		JButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 new UpdateDeleteStudents().setVisible(true);
			}
		});
		JButton3.setBounds(20, 189, 271, 39);
		JButton3.setIcon(new ImageIcon(home.class.getResource("/images/Update & Delete Student.png")));
		JButton3.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton3);
		
		JButton JButton4 = new JButton("Student Fees");
		JButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 new StudentFees1().setVisible(true);
			}
		});
		
		JButton4.setBounds(21, 239, 270, 43);
		JButton4.setIcon(new ImageIcon(home.class.getResource("/images/Fees.png")));
		JButton4.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton4);
		
		JButton JButton5 = new JButton("All Student Living");
		JButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				new AllStudentsLiving().setVisible(true);
			}
		});
		JButton5.setBounds(20, 293, 271, 43);
		JButton5.setIcon(new ImageIcon(home.class.getResource("/images/all student living.png")));
		JButton5.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton5);
		
		JButton JButton6 = new JButton("Leaved Student");
		JButton6.setBounds(20, 347, 271, 39);
		JButton6.setIcon(new ImageIcon(home.class.getResource("/images/Leaved students.png")));
		JButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				new LeavedStudents().setVisible(true);
			}
		});
		JButton6.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton6);
		
		JButton JButton7 = new JButton("New Employee");
		JButton7.setBounds(20, 397, 271, 43);
		JButton7.setIcon(new ImageIcon(home.class.getResource("/images/new student.png")));
		JButton7.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton7);
		JButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
                              
                        new NewEmplyoee().setVisible(true); 
			}
		});
		
		
		
		JButton JButton8 = new JButton("Update & Delete Employee");
		JButton8.setBounds(20, 451, 271, 43);
		JButton8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				new UpdateDeleteEmployee().setVisible(true);
			}
			
		});
		JButton8.setIcon(new ImageIcon(home.class.getResource("/images/Update & Delete Student.png")));
		JButton8.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton8);
		
		JButton JButton10 = new JButton("All Employee Working");
		JButton10.setBounds(20, 558, 271, 42);
		JButton10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AllEmployeeWorking().setVisible(true);
			}
		});
		JButton10.setIcon(new ImageIcon(home.class.getResource("/images/all student living.png")));
		JButton10.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton10);
		
		JButton JButton9 = new JButton("Employee Payment");
		JButton9.setBounds(20, 505, 271, 42);
		JButton9.setIcon(new ImageIcon(home.class.getResource("/images/Fees.png")));
		JButton9.setFont(new Font("Sitka Display", Font.BOLD, 18));
		JButton9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new EmployeePayment().setVisible(true);
			}
		});
		contentPane.add(JButton9);
		
		JButton JButton11 = new JButton("Leaved Employee");
		JButton11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LeavedEmployee().setVisible(true);
			}
		});
		JButton11.setBounds(20, 611, 265, 42);
		JButton11.setIcon(new ImageIcon(home.class.getResource("/images/Leaved students.png")));
		JButton11.setFont(new Font("Sitka Display", Font.BOLD, 18));
		contentPane.add(JButton11);
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int a=JOptionPane.showConfirmDialog(null,"Do You Really Want to logout","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					setVisible(false);
					new login().setVisible(true);
				}
			}
		});
		btnLogOut.setBounds(900, 11, 165, 61);
		btnLogOut.setIcon(new ImageIcon(home.class.getResource("/images/logout.png")));
		btnLogOut.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(btnLogOut);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int a=JOptionPane.showConfirmDialog(null,"Do You Really Want to Exit ","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					System.exit(0);
				}
				
			}
		});
		btnExit.setBounds(1150, 11, 165, 61);
		btnExit.setIcon(new ImageIcon(home.class.getResource("/images/Close.png")));
		btnExit.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(btnExit);
		
		
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(home.class.getResource("/images/home background.PNG")));
		lblNewLabel.setBounds(0, 0, 1350, 729);
		contentPane.add(lblNewLabel);
	}
}
