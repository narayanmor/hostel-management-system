import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Project.ConnectionProvider;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class ManageRoom extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private JCheckBox chckbxYes_1;
	private JCheckBox chckbxYes_2;

	
	public void clear()
	{
		textField.setText(""); 
		textField_1.setText("");
		chckbxYes_1.setSelected(false);
		chckbxYes_2.setSelected(false);
		textField_1.setBackground(new JButton().getBackground());
		textField_1.setForeground(new JButton().getForeground());
		textField_1.setEditable(false);

	 
	}
	
	public void tableDetails()
	{
		DefaultTableModel dtm=(DefaultTableModel) table.getModel(); 
		table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		dtm.setRowCount(0);
		try
		{
			Connection con=ConnectionProvider.getCon();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select *from room");
			while(rs.next())
			{
				dtm.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3)});
			}

		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
	}
 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageRoom frame = new ManageRoom();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageRoom() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(380, 150, 900, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 192, 203));
		contentPane.setFont(new Font("Sylfaen", Font.BOLD, 15));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddNewRoom = new JLabel("Add New Room");
		lblAddNewRoom.setBounds(10, 11, 213, 35);
		lblAddNewRoom.setFont(new Font("Algerian", Font.BOLD, 21));
		contentPane.add(lblAddNewRoom);
		
		JLabel lblRoom = new JLabel("Room Number");
		lblRoom.setBounds(10, 67, 128, 27);
		lblRoom.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(lblRoom);
		
		textField = new JTextField();
		textField.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField.setBounds(146, 68, 144, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblActivate = new JLabel("Activate Or Deactivate");
		lblActivate.setBounds(302, 70, 200, 21);
		lblActivate.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(lblActivate);
		
		JCheckBox chckbxYes_2 = new JCheckBox("Yes");
		chckbxYes_2.setBounds(521, 67, 58, 26);
		chckbxYes_2.setFont(new Font("Sylfaen", Font.BOLD, 16));
		contentPane.add(chckbxYes_2);
		
		JButton button = new JButton(" ");
		button.setBounds(787, 11, 83, 48);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setVisible(false);
			}
		});
		button.setFont(new Font("Tahoma", Font.PLAIN, 6));
		button.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/Close all jframe.png")));
		contentPane.add(button);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(638, 63, 101, 35);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String rn=textField.getText();
				String act;
				String rs="Not Booked";
				if(chckbxYes_2.isSelected())
				{
					act="yes";
					
				}
				else {
				
				
					act="no";
				}
				try
				{
					Connection con=ConnectionProvider.getCon();
					PreparedStatement ps=con.prepareStatement("INSERT INTO `room`(number,activate,roomStatus) VALUES ('"+rn+"','"+act+"','"+rs+"')");
					Pattern p1= Pattern.compile("^[0-9]{3}$");
					Matcher m1=p1.matcher(textField.getText());
					if(!m1.matches())
					{
						JOptionPane.showMessageDialog(null,"Plz Enter Room Number...");
						return ;
					}
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null," Rooms Are SuccessFully Added");
					tableDetails();
					clear(); 
					
				}
				catch(Exception e)
				{
					
				}
				
			}
		});
		btnSave.setFont(new Font("Sylfaen", Font.BOLD, 17));
		btnSave.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/save.png")));
		contentPane.add(btnSave);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 105, 890, 2);
		contentPane.add(separator);
		
		JLabel lblUpdatedelete = new JLabel("Update & Delete Room");
		lblUpdatedelete.setBounds(10, 118, 264, 21);
		lblUpdatedelete.setFont(new Font("Algerian", Font.BOLD, 21));
		contentPane.add(lblUpdatedelete);
		
		JLabel lblRoomNumber = new JLabel("Room Number");
		lblRoomNumber.setBounds(10, 173, 126, 24);
		lblRoomNumber.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(lblRoomNumber);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
		textField_1.setBounds(146, 172, 144, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblActivateOrDeactivate = new JLabel("Activate Or Deactivate");
		lblActivateOrDeactivate.setBounds(460, 172, 190, 27);
		lblActivateOrDeactivate.setFont(new Font("Sylfaen", Font.BOLD, 17));
		contentPane.add(lblActivateOrDeactivate);
		
		JCheckBox chckbxYes_1 = new JCheckBox("Yes");
		chckbxYes_1.setBounds(681, 172, 58, 27);
		chckbxYes_1.setFont(new Font("Sylfaen", Font.BOLD, 16));
		contentPane.add(chckbxYes_1);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String rn=textField_1.getText();
				String act;
				if(chckbxYes_1.isSelected())
				{
				act="yes";
				}
				else
				{
					act="no";
				}
					try
				{
					Connection con=ConnectionProvider.getCon();
					Statement st=con.createStatement();


					
					st.executeUpdate("UPDATE room SET activate='"+act+"'where number='"+rn+"'");
					JOptionPane.showMessageDialog(null,"Rooms Are  Successfully Updated");
					tableDetails();
					clear();
				}
				catch(Exception e)
				{
					
				}
			}
		});
		btnUpdate.setBounds(459, 237, 120, 35);
		btnUpdate.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnUpdate.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/save.png")));
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String rn=textField_1.getText();
				try
				{
					Connection con=ConnectionProvider.getCon();
					Statement st=con.createStatement();
					st.executeUpdate("DELETE FROM room WHERE number='"+rn+"'");


					JOptionPane.showMessageDialog(null,"Rooms Are Successfully deleted");
					tableDetails();
					clear();
				}
				catch(Exception e)
				{
				
				}
			}
			
		});
		btnDelete.setBounds(623, 237, 116, 34);
		btnDelete.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnDelete.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/delete.png")));
		contentPane.add(btnDelete);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String rn=textField_1.getText();
			int i=0;
			try
			{
				Connection con=ConnectionProvider.getCon();
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("SELECT *FROM room WHERE number='"+rn+"'");
				while(rs.next())
				{
					i=1;
					if(rs.getString(3).equals("Booked"))
					{
						JOptionPane.showMessageDialog(null,"this Room is booked");
						clear(); 
					}
					else
					{
						textField_1.setEditable(false);
						textField_1.setForeground(Color.RED);
						textField_1.setBackground(Color.PINK);
						if(rs.getString(2).equals("yes"))
							
							chckbxYes_1.setSelected(true);
						
						else
							
							chckbxYes_1.setSelected(false);
							
							
					} 
				}
				if(i==0)
				{
					JOptionPane.showMessageDialog(null,"Room No Does Not Exit");
					clear();
				}
			}

			catch(Exception e)
			{
				
			}
			}
			
		});
		btnSearch.setBounds(318, 168, 110, 35);
		btnSearch.setFont(new Font("Sylfaen", Font.BOLD, 16));
		btnSearch.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/search.png")));
		contentPane.add(btnSearch);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(10, 282, 880, 2);
		contentPane.add(separator_1);
		
		JLabel lblAllRoom = new JLabel("All Rooms");
		lblAllRoom.setBounds(320, 295, 138, 35);
		lblAllRoom.setFont(new Font("Algerian", Font.BOLD, 21));
		contentPane.add(lblAllRoom);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(88, 341, 651, 130);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Poor Richard", Font.BOLD, 14));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Number", "Activate", "RoomStatus"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnPrint = new JButton("Print");
		btnPrint.setIcon(new ImageIcon(ManageRoom.class.getResource("/images/print.png")));
		btnPrint.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try
				{
					 table.print(JTable.PrintMode.FIT_WIDTH);
				}
				catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null, e1);
				}
			}
		});
		btnPrint.setBounds(754, 484, 116, 35);
		contentPane.add(btnPrint);
	tableDetails();
	dispose();
	}
}
